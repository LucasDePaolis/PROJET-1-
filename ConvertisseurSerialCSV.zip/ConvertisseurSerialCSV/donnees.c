#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "donnees.h"
#include "choice.h"

#define DELIM        ";"
#define BUFF_SIZE    128

int launch(int UserChoice,int Choice) {

        contact_infos * infos = get_contact ("contacts.csv",UserChoice,Choice);
        free_contact_infos (& infos);
}

char * str_dup (const char * str)
{
   char * dup = NULL;


   if (str != NULL)
   {
      size_t size = strlen (str) + 1;
      dup = malloc (size);

      if (dup != NULL)
      {
         memcpy (dup, str, size);
      }
   }
   return dup;
}



void free_contact_infos (contact_infos ** p)
{
   if (p != NULL && *p != NULL)
   {
      free ((*p)->pouls);
   /* free ((*p)->jours);
      free ((*p)->mois);
      free ((*p)->heures);
      free ((*p)->minutes);
      free ((*p)->secondes); */
      free ((*p)->millis);
    //free ((*p)->dollard);

      free (*p);
      *p = NULL;
   }
}


contact_infos * get_contact (const char * nomcontact, int UserChoice, int Choice)
{
   contact_infos  *  infos = NULL;
   FILE           *  file  = NULL;
   char           *  token = NULL;
   char              buff [BUFF_SIZE];
   int tableau[128];
   int j=0;
   int average =0;
   file = fopen ("nomcontact.csv", "r");



   if (file != NULL)
   {
      while((fgets (buff, BUFF_SIZE, file)) != NULL)
      {
         char *   p = buff;
         int      i = 0;


         infos = malloc (sizeof (* infos));

         if (infos != NULL)
         {

            while ((token = strtok (p, DELIM)) != NULL)
            {
               if (i == 0)
                p = NULL;

               switch (i)
               {
                  case POULS:
                      {
                     int pouls = strtol (token, NULL, 10);
                     infos->pouls = pouls;
                     if (UserChoice == 1 || UserChoice == 3 || Choice !=NULL){
                        tableau[j]= infos->pouls;
                        j++;
                     }

                      }

                     break;

 /*                 case JOURS:
                     infos->jours = str_dup (token);
                     printf("Date : %s/",infos->jours);
                     break;

                  case MOIS:
                     infos->mois = str_dup (token);
                     printf("%s\n",infos->mois);
                     break;

                  case HEURES:
                     infos->heures = str_dup (token);
                     printf("%s:",infos->heures);
                     break;

                  case MINUTES:
                     infos->minutes = str_dup (token);
                     printf("%s:",infos->minutes);
                     break;


*/
                  case MILLIS:
                      {
                     int millis = strtol (token, NULL, 10);
                     infos->millis = millis;
                     if (UserChoice == 2 || UserChoice == 4){
                        tableau[j]= infos->millis;
                        j++;
                       }
                     }
                      break;

 /*                 case DOLLARD:
                     infos->dollard = str_dup (token);
                     break;
*/
                  default:
                    break;

               }
               i++;
            }
         }
      }

      if (Choice == 1)
      {
           for (int k = 0 ; k < j ; k++) //mettre j pour le poul k<j
        {
            printf("%d bpm/ ", tableau[k]);
        }
      }
      else if (Choice == 3)
      {
          for (int k = 0 ; k < j ; k++)
        {
            average += tableau[k];
        }
        printf("Average Pulse : %d \n", average/j);
      }

    int valeurtemporaire, x, w;
    int tailletableau=j;

     for (x=0; x<tailletableau; x++)
     {
        for(w=x; w<tailletableau; w++)
        {
            if (UserChoice ==3 || UserChoice ==4 )
            {
                if(tableau[w]>tableau[x])  /* si on inverse le signe d'in�galit�
                                            on aura le trie croissant */
                {
                    valeurtemporaire = tableau[x];
                    tableau[x] = tableau[w];
                    tableau[w] = valeurtemporaire;
                }

            }
            else if (UserChoice ==1|| UserChoice ==2 || Choice == 5 || Choice == 6)
            {
                if(tableau[w]<tableau[x])  // DECROISSANT
                {
                    valeurtemporaire = tableau[x];
                    tableau[x] = tableau[w];
                    tableau[w] = valeurtemporaire;
                }
            }
        }
     }
        if (Choice == 0)
        {
            for (int k = 0 ; k < j ; k++) //mettre j pour le poul k<j
        {
            printf("%d / ", tableau[k]);
        }
        }
        else if(Choice != 0)
        {
            if (Choice == 5){

          printf("\n The highest pulse is %d bpm \n ",tableau[j-1]);
        }
             else if (Choice == 6){
          printf("\n The lowest pulse is %d bpm\n",tableau[0]);
        }
        else if (Choice == 4){
            printf("there is %d lines ",j);
        }
        else if (Choice == 2)
        {
            int rech;
            int verif = 1;
            printf("Choose a pulse value\n");
            scanf("%d",&rech);
            for (int r=0; r<j;r++)
            {
                if(rech == tableau[r]){
                    printf("%d bpm disponible est %d\n",rech,r+1);
                    verif++;
                }

            }
            if(verif==1)
            {
                printf("This value doesn't exist, please select another value [50,220]\n");
            }
        }
        }
      fclose (file);
   }
   return infos;
}


