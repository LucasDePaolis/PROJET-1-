#ifndef PARAM_H_
#define PARAM_H_
#define mode (5)
#endif
