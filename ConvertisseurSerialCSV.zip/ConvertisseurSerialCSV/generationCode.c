#include <stdio.h>
#include <stdlib.h>


void file(model){
    FILE* param = NULL;
    param = fopen("CoeurLed/param.h", "w+");
    fprintf(param,"#ifndef PARAM_H_\n");
    fprintf(param,"#define PARAM_H_\n");
    fprintf(param,"#define mode (%d)\n", model);
    fprintf(param,"#endif\n");
    fclose(param);
}
