#ifndef CHOICE_H_INCLUDED
#define CHOICE_H_INCLUDED

int ChoiceMenu(int UserChoice,int exit);
int ChoiceSort(int UserChoice, int exit);
int ChoiceSearchAndShow(int Choice, int exit);
int Leave(int exit);

#endif // CHOICE_H_INCLUDED
