#include <stdio.h>
#include <stdlib.h>
#include "generationCode.h"
#include "choice.h"
#include "menu.h"

void Menu() {
    int UserChoice = 0;
    int exit = 1;
    do{
        do{
            system("cls");
            printf("1.Sort the data\n");
            printf("2.Search a data\n");
            printf("3.Mode LED\n");
            printf("0.Leave\n");
            scanf("%d", &UserChoice);
        }while(UserChoice > 3);
            exit = ChoiceMenu(UserChoice, exit);
    }while(exit==1);

}

void Sort() {
    int exit = 1;
    int UserChoice;
    do{
        do{
            system("cls");
            printf("1.Pulse(ascending order)\n");
            printf("2.Time(ascending order)\n");
            printf("3.Pulse(descending order)\n");
            printf("4.Time(descending order)\n");
            printf("0.Return previous menu\n");
            scanf("%d", &UserChoice);
        }while(UserChoice > 4);
        exit = ChoiceSort(UserChoice, exit);
    }while(exit==1);
}

void SearchAndShow() {
    int Choice;
    int exit = 1;
    do{
            do{
                system("cls");
                printf("1.Show patient records\n");
                printf("2.Search a data\n");
                printf("3.Show the average pulse in a time laps\n");
                printf("4.Show the amount of data lines\n");
                printf("5.Search the highest pulse\n");
                printf("6.Search the lowest pulse\n");
                printf("0.Return previous menu\n");
                scanf("%d", &Choice);

            }while(Choice > 6);
                exit = ChoiceSearchAndShow(Choice, exit);
    }while(exit == 1);

}

void ModeLED() {
    int UserChoice;
    int exit = 1;
    do{
        do{
            system("cls");
            printf("Which mode do you choose?\n");
            printf("0.Every LED One by One\n");
            printf("1.Caterpillar\n");
            printf("2.One LED on Two\n");
            printf("3.Every LED at the same time\n");
            printf("4.One LED on Three\n");
            printf("5.Return previous menu\n");
            scanf("%d", &UserChoice);
            if(UserChoice<=5){
                file(UserChoice);
            }
        }while(UserChoice>5);
        exit = Leave(exit);
    }while(exit == 1);
}

int Leave(int exit){
    exit++;
    return exit;
}

