#include <stdlib.h>
#include <stdio.h>
#include "menu.h"
#include "donnees.h"
#include "choice.h"
#include <stdbool.h>

int ChoiceMenu(int UserChoice, int exit) {
    switch(UserChoice){
        case 1:
            Sort();
            return exit;
            break;
        case 2:
            SearchAndShow();
            return exit;
            break;

        case 3:
            ModeLED();
            return exit;
            break;
        case 0:
            exit = Leave(exit);
            return exit;
            break;
    }


}

int ChoiceSort(int UserChoice, int exit) {
    int Choice = 0;
    switch(UserChoice){


        case 1:
            launch(UserChoice, Choice); // Pulse croissant
            printf("\n");
            system("pause");
            return exit;
            break;

        case 2:
            launch(UserChoice,Choice); // Time croissant
            printf("\n");
            system("pause");
            return exit;
            break;

        case 3:
            launch(UserChoice,Choice); // Pulse d�croissant
            printf("\n");

            system("pause");
            return exit;
            break;

        case 4:
            launch(UserChoice,Choice); // Time d�croissant
            printf("\n");
            system("pause");
            return exit;
            break;

        case 0:
            exit = Leave(exit);
            return exit;
            break;
    }
}

int ChoiceSearchAndShow(int Choice,int exit){

    switch(Choice){
        int UserChoice =0;
    case 1:
        launch(UserChoice,Choice);
        printf("\n");
        system("pause");
        return exit;
        break;
    case 2:
        launch(UserChoice,Choice);
        printf("\n");
        system("pause");
        return exit;
        break;
    case 3:
        launch(UserChoice,Choice);
        printf("\n");
        system("pause");
        return exit;
        break;
    case 4:
        launch(UserChoice,Choice); //nbre de ligne dns le csv
        printf("\n");
        system("pause");
        return exit;
        break;
    case 5:
        launch(UserChoice,Choice); //maximumm
        printf("\n");
        system("pause");
        return exit;
        break;
    case 6:
        launch(UserChoice,Choice); //minimum
        printf("\n");
        system("pause");
        return exit;
        break;
    case 0:
        exit = Leave(exit);
        return exit;
        break;

    }
}
/*
int rechercheDicho(int tab[], int nbVal, int val){



  bool trouve = false;
  int idebut = 0;
  int ifin = nbVal;
  int imilieu;


  while(!trouve && ((ifin - idebut) > 1)){

    imilieu = (idebut + ifin)/2;

    trouve = (tab[imilieu] == val);


    if(tab[imilieu] > val) ifin = imilieu;
    else idebut = imilieu;

  }
  if(tab[idebut] == val) return(idebut);

  else return(-1);

}








*/












