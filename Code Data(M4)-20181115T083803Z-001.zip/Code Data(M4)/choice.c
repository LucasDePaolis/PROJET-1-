#include <stdlib.h>
#include <stdio.h>
#include "menu.h"

int ChoiceMenu(int UserChoice, int exit) {
    exit=1;
    switch(UserChoice){
        case 1:
            Sort();
            return exit;
            break;
        case 2:
            SearchAndShow();
            return exit;
            break;
        case 0:
            exit = Leave(exit);
            return exit;
            break;
    }

}

int ChoiceSort(int UserChoice, int exit) {
    exit = 1;
    switch(UserChoice){
        case 1:

            return exit;
            break;
        case 2:

            return exit;
            break;

        case 3:

            return exit;
            break;

        case 4:

            return exit;
            break;

        case 0:
            exit = Leave(exit);
            return exit;
            break;
    }
}

int ChoiceSearchAndShow(int UserChoice, int exit){
    exit = 1;
    switch(UserChoice){
    case 1:

        return exit;
        break;
    case 2:

        return exit;
        break;
    case 3:
        return exit;
        break;
    case 4:

        return exit;
        break;
    case 5:

        return exit;
        break;
    case 6:

        return exit;
        break;
    case 0:
        exit = Leave(exit);
        return exit;
        break;

    }
}

int ChoiceTimePulse(){
    int UserChoice = 0;
    int exit = 1;
    do{
        printf("1.Time\n");
        printf("2.Pulse\n");
        printf("0.Leave");
        scanf("%d", &UserChoice);
    }while(UserChoice > 2);

    if(UserChoice == 0){
        exit = Leave(exit);
    }
}






















