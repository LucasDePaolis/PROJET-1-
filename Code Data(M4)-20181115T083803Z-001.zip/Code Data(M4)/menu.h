#ifndef BIBLIO_H_INCLUDED
#define BIBLIO_H_INCLUDED

void menu();
void SearchAndShow();
void Sort();
int Leave(int exit);

#endif // BIBLIO_H_INCLUDED
