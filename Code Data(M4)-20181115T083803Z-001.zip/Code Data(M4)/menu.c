#include <stdio.h>
#include <stdlib.h>


void Menu() {
    int UserChoice = 0;
    int exit = 1;
    do{
        do{
            system("cls");
            printf("1.Sort the data\n");
            printf("2.Search a data\n");
            printf("0.Leave\n");
            scanf("%d", &UserChoice);
        }while(UserChoice > 2);
            exit = ChoiceMenu(UserChoice, exit);
    }while(exit==1);

}

void Sort() {
    int exit = 0;
    int UserChoice = 0;
    do{
            do{
                system("cls");
                printf("1.Pulse(ascending order)\n");
                printf("2..Time(ascending order)\n");
                printf("3.Pulse(descending order)\n");
                printf("4.Time(descending order)\n");
                printf("0.Leave\n");
                scanf("%d", &UserChoice);
            }while(UserChoice > 4);
                exit = ChoiceSort(UserChoice, exit);
    }while(exit==1);
}

void SearchAndShow() {
    int UserChoice;
    int exit = 1;
    do{
            do{
                system("cls");
                printf("1.Show patient records\n");
                printf("2.Search a data\n");
                printf("3.Show the average pulse in a time laps\n");
                printf("4.Show the amount of data lines\n");
                printf("5.Search the highest pulse\n");
                printf("6.Search the lowest pulse\n");
                printf("7.\n");
                printf("0.Leave\n");
                scanf("%d", &UserChoice);
            }while(UserChoice > 6);
                exit = ChoiceSearchAndShow(UserChoice, exit);
    }while(exit == 1);

}

int Leave(int exit){
    exit++;
    return exit;
}

