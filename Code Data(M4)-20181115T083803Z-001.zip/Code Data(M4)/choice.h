#ifndef CHOICE_H_INCLUDED
#define CHOICE_H_INCLUDED

int ChoiceMenu(int UserChoice,int exit);
int ChoiceSort(int UserChoice, int exit);
int ChoiceSearchAndShow(int UserChoice, int exit);
void ChoiceTimePulse();
int Leave(int exit);

#endif // CHOICE_H_INCLUDED
