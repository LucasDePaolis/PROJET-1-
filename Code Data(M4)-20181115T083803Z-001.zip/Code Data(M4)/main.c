#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "actions.h"
#include "choice.h"

int main(){
    Menu();
}

